# Master Linux Command Line in 30 Comprehensive Chapters — 530 Hands‑On Exercises

Assets for the book cover + favicon.

## Files
- `assets/cover.png` — book cover (front)
- `favicon.ico` — multi-size favicon (16–256)
- `assets/favicon-16x16.png`, `assets/favicon-32x32.png`, ... — PNG variants
- `assets/favicon-1024.png` — source square icon (1024×1024)

## HTML usage
```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon-16x16.png">
```
